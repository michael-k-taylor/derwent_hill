<article class="qodef-pl-item qodef-item-space <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>">
	<div class="qodef-pl-item-inner">
		<?php echo xtrail_core_get_cpt_shortcode_module_template_part( 'portfolio', 'portfolio-list', 'layout-collections/' . $item_style, '', $params ); ?>
	</div>
</article>