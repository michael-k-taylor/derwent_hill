<?php

include_once XTRAIL_CORE_SHORTCODES_PATH.'/perspective-scroll/functions.php';
include_once XTRAIL_CORE_SHORTCODES_PATH.'/perspective-scroll/perspective-scroll.php';