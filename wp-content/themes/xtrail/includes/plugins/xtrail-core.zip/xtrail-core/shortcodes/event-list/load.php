<?php

include_once XTRAIL_CORE_SHORTCODES_PATH . '/event-list/functions.php';
include_once XTRAIL_CORE_SHORTCODES_PATH . '/event-list/event-list.php';