<?php

include_once XTRAIL_CORE_SHORTCODES_PATH . '/interactive-image-with-text/functions.php';
include_once XTRAIL_CORE_SHORTCODES_PATH . '/interactive-image-with-text/interactive-image-with-text.php';