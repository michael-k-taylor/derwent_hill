<?php
include_once XTRAIL_CORE_SHORTCODES_PATH.'/linked-images/linked-images.php';
include_once XTRAIL_CORE_SHORTCODES_PATH.'/linked-images/linked-image.php';
include_once XTRAIL_CORE_SHORTCODES_PATH.'/linked-images/functions.php';
