<?php

include_once XTRAIL_CORE_SHORTCODES_PATH . '/number-with-text/functions.php';
include_once XTRAIL_CORE_SHORTCODES_PATH . '/number-with-text/number-with-text.php';