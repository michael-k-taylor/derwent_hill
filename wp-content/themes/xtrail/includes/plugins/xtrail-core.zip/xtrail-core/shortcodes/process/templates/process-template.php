<div class="qodef-process-holder <?php echo esc_attr( $holder_classes ); ?>">
	<div class="qodef-process-inner">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>